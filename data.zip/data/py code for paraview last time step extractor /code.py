from paraview.simple import *
import os

# Get the active source
data = GetActiveSource()  

# Set the animation time to a specific timestep value
last_time_step = data.TimestepValues[640]
animationScene = GetAnimationScene()
animationScene.AnimationTime = last_time_step

# Render the scene to update the frame
Render()

# Define the output directory and file name
output
