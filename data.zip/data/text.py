from paraview.simple import *
import os

# Get the active source
data = GetActiveSource()  

# Set the animation time to a specific timestep value
last_time_step = data.TimestepValues[640]
animationScene = GetAnimationScene()
animationScene.AnimationTime = last_time_step

# Render the scene to update the frame
Render()

# Save the data at the specific timestep
output_file = "output_data.vtk"  # Specify your desired output file name and format
SaveData(output_file, proxy=data)
